package br.liveo.ndrawer.ui.activity;

/**
 * Created by rupa.dwivedi on 02-03-2016.
 */
public class Person {
  /*  String name;
    String age;*/
    String Company_Name;
    String Position;
    String From_Date;
    String To_Date;
    String Training_Name,Age_Nominee;
    String  Date_ofCompletion;
    String training_name;
    String date_ofcompletion,certification_number,institute;
    String  Month,Year,NetPay;
  String Name,Address,Relation,Name_Address_Guardian,DOB,AmountPaidToNominee,Age;
  String pfMonth;
  String pfYear;
  String pfdate;
  String pfPerMonth;
  String employeeCumulative;
  String EPF;
  String employerCumulative;
  String FPF;
  String Cumulative;
  String Total;
  String VPF;
  String PfAccNo;

  String salaryNetPay;
  String salaryyear,salarymonth;
  String loanDate,LoanCode,LoanDescription,loanAmount,loanPaid,loanBalance,loanDateString;

    Person(String trim, String s,String h,String j) {

    }
  Person() {

  }

  public Person(String trim2, String s1, String s, String trim, String trim1) {

  }

  public Person(String trim) {

  }

  public Person(String Age_Nominee, String trim, String trim1, String trim2, String trim3, String trim4, String trim5) {
  }
}
