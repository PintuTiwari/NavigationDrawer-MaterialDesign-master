package br.liveo.ndrawer.ui.activity;

import android.view.View;

/**
 * Created by rupa.dwivedi on 18-04-2016.
 */
public interface OnItemClickListener extends br.liveo.interfaces.OnItemClickListener {
    void onItemClicked(View v);


}
