package br.liveo.ndrawer.ui.activity;

class Person1 {

    String training_name;
    String date_ofcompletion,certification_number,institute;
   Person1(String Date_ofCompletion, String date_ofcompletion, String certification_number, String institute) {

   }

    public Person1() {

    }
}